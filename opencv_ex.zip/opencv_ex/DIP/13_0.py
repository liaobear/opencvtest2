import cv2
import numpy as np

flags = [i for i in dir(cv2) if i.startswith('COLOR_')]

print(flags)
